
//#include <TinyGPS.h>
#define PIN_TX    10
#define PIN_RX    11
#define BAUDRATE  9600
#define PHONE_NUMBER "9154246487"  
String MESSAGE;

